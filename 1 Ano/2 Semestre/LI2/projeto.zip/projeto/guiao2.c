#include "main.h"

// Função para desfazer a última ação.
void undo(Gamestate **state) {
    if ((*state)->prev != NULL) {
        Gamestate *temp = *state;
        *state = (*state)->prev;
        (*state)->next = NULL;
        temp->prev = NULL;
    } else
        printf("Não existe um estado anterior.\n");
}

// Função para verificar se existem casas repetidas de uma pintada.
int verify_paint(Gamestate *state, int row, int col, int supress) {
     char *abc = "abcdefghijklmnopqrstuvxyz";
     char at = state->board[row][col];
     int tot = 0;
     for (int j = col; j < state->columns; j++) {
         if(at == state->board[row][j] && j != col){
            if (!supress)
                printf("Existem duas réplicas de %c nas posições %c%d %c%d.\n",
                    at, abc[col], row+1, abc[j], row+1);
            tot++;
         }
     }
     for (int i = row; i < state->lines; i++) {
         if(at == state->board[i][col] && i != row){
            if (!supress)
                printf("Existem duas réplicas de %c nas posições %c%d %c%d.\n",
                    at, abc[col], row+1, abc[col], i+1);
            tot++;
         }
     }
     return tot;
}

// Função para verificar se existem casas não pintadas à volta de uma casa marcada.
int verify_mark(Gamestate *state, int row, int col, int supress) {
    char *abc = "ABCDEFGHIJKLMNOPQRSTUVXYZ";
    int tot = 0;
    if (col + 1 < state->columns && !strchr(abc, state->board[row][col + 1])){
        if (!supress)
            printf("Existem casas não pintadas à volta de %c%d.\n", tolower(abc[col]), row + 1);
        tot++;
    }
    else if (col - 1 >= 0 && !strchr(abc, state->board[row][col - 1])){
        if (!supress)
            printf("Existem casas não pintadas à volta de %c%d.\n", tolower(abc[col]), row + 1);
        tot++;
    }
    else if (row - 1 >= 0 && !strchr(abc, state->board[row - 1][col])){
        if (!supress)
            printf("Existem casas não pintadas à volta de %c%d.\n", tolower(abc[col]), row + 1);
        tot++;
    }
    else if (row + 1 < state->lines && !strchr(abc, state->board[row + 1][col])){
        if (!supress)
            printf("Existem casas não pintadas à volta de %c%d.\n", tolower(abc[col]), row + 1);
        tot++;
    }
    return tot;
}

// Função para verificar todas as casas pintadadas e marcadas
int verify(Gamestate *state, int supress) {
    int tot = 0;
    for (int i = 0; i < state->lines; i++) {
        for (int j = 0; j < state->columns; j++) {
            if (state->board[i][j] >= 'A' && state->board[i][j] <= 'Z')
                tot += verify_paint(state, i, j, supress);
            else if (state->board[i][j] == '#')
                tot += verify_mark(state, i, j, supress);
        }
    }
    if (are_painted_cells_connected(state) == 0){
        if (!supress)
            printf("As casas pintadas não estão ligadas.\n");
        tot++;
    }
    return tot;
}

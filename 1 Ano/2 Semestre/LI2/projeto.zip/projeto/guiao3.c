#include "main.h"

// Liberta a memória do array visitado
void free_visited(int **visited, int rows) {
    if (visited == NULL) return;
    for (int i = 0; i < rows; i++) {
        free(visited[i]);
    }
    free(visited);
}

// Algoritmo flood-fill(DFS) para marcar casas pintadas ligadas ortogonalmente
void flood_fill(Gamestate *state, int row, int col, int **visited) {
    if (row < 0 || row >= state->lines || col < 0 || col >= state->columns)
        return;
    if (visited[row][col] == 1 || state->board[row][col] < 'A' || state->board[row][col] > 'Z')
        return;
    visited[row][col] = 1;
    flood_fill(state, row - 1, col, visited);     // Up
    flood_fill(state, row + 1, col, visited);     // Down
    flood_fill(state, row, col - 1, visited);     // Left
    flood_fill(state, row, col + 1, visited);     // Right
}

// Função para verificar se todas as casas pintadas estão ligadas
int check_connected(Gamestate *state, int **visited) {
    for (int i = 0; i < state->lines; i++) {
        for (int j = 0; j < state->columns; j++) {
            if (state->board[i][j] >= 'A' && state->board[i][j] <= 'Z' && visited[i][j] == 0)
                return 0; // Found a painted cell that is not connected
        }
    }
    return 1;
}

// Função para verificar se todas as casas pintadas estão ligadas ortogonalmente
int are_painted_cells_connected(Gamestate *state) {
    int **visited = malloc(state->lines * sizeof(int *));
    if (visited == NULL) 
        exit_error("Failed to allocate memory");
    for (int i = 0; i < state->lines; i++) {
        visited[i] = calloc(state->columns, sizeof(int));
        if (visited[i] == NULL)
            exit_error("Failed to allocate memory");
    }
    int start_row = -1, start_col = -1;
    for (int i = 0; i < state->lines; i++) {
        for (int j = 0; j < state->columns; j++) {
            if (state->board[i][j] >= 'A' && state->board[i][j] <= 'Z') {
                start_row = i;
                start_col = j;
                break;
            }
        }
        if (start_row != -1) 
            break;
    }
    if (start_row == -1) {
        free_visited(visited, state->lines);
        return 1;
    }
    flood_fill(state, start_row, start_col, visited);
    int result = check_connected(state, visited);
    free_visited(visited, state->lines);
    return result;
}

#include "main.h"

// Regra 1: Risca todas as casas iguais a uma branca
void mark_next_painted(Gamestate *state, Gamestate **new_state) {
    char *abc = "ABCDEFGHIJKLMNOPQRSTUVXYZ";
    for (int i = 0; i < (*new_state)->lines; i++) {
        for (int j = 0; j < (*new_state)->columns; j++) {
            if (strchr(abc, state->board[i][j])){
                char charmin = tolower(state->board[i][j]);
                for (int k = i + 1; k < (*new_state)->lines;k++){
                    if (state->board[k][j] == charmin)
                        (*new_state)->board[k][j] = '#';
                }
                for (int k = j + 1; k < (*new_state)->columns;k++){
                    if (state->board[i][k] == charmin)
                        (*new_state)->board[i][k] = '#';
                }
            }
        }
    }
}

// Regra 2: Pinta as casas vizinhas de uma casa riscada
void paint_next_mark(Gamestate *state, Gamestate **new_state) {
    for (int i = 0; i < (*new_state)->lines; i++) {
        for (int j = 0; j < (*new_state)->columns; j++) {
            if (state->board[i][j] == '#') {
                if (i > 0) 
                    (*new_state)->board[i - 1][j] = toupper((*new_state)->board[i - 1][j]);
                if (i < (*new_state)->lines - 1) 
                    (*new_state)->board[i + 1][j] = toupper((*new_state)->board[i + 1][j]);
                if (j > 0) 
                    (*new_state)->board[i][j - 1] = toupper((*new_state)->board[i][j - 1]);
                if (j < (*new_state)->columns - 1) 
                    (*new_state)->board[i][j + 1] = toupper((*new_state)->board[i][j + 1]);
            }
        }
    }
}

// Regra 3: Pinta as casas que ficariam isoladadas
void isolation_paint(Gamestate *state, Gamestate **new_state) {
    char *abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    for (int i = 0; i < (*new_state)->lines; i++) {
        for (int j = 0; j < (*new_state)->columns; j++) {
            if (strchr(abc, state->board[i][j])) {
                int blocked = 0; // Contador de vizinhos bloqueados
                int free_i = -1, free_j = -1; // Coordenadas do vizinho livre
                if (i - 1 < 0 || state->board[i - 1][j] == '#')
                    blocked++;
                else {
                    free_i = i - 1;
                    free_j = j;
                }
                if (i + 1 >= (*new_state)->lines || state->board[i + 1][j] == '#')
                    blocked++;
                else {
                    free_i = i + 1;
                    free_j = j;
                }  
                if (j - 1 < 0 || state->board[i][j - 1] == '#')
                    blocked++;
                else {
                    free_i = i;
                    free_j = j - 1;
                }
                if (j + 1 >= (*new_state)->columns || state->board[i][j + 1] == '#')
                    blocked++;
                else {
                    free_i = i;
                    free_j = j + 1;
                }
                // Se 3 vizinhos são bloqueados, pintar o vizinho livre
                if (blocked == 3 && free_i != -1 && free_j != -1)
                    (*new_state)->board[free_i][free_j] = toupper(state->board[free_i][free_j]);
            }
        }
    }
}

// Função para aplicar as regras do jogo
Gamestate *apply_rules(Gamestate *state) {
    Gamestate *new_state = duplicate_gamestate(state);
    mark_next_painted(state, &new_state);
    paint_next_mark(state, &new_state);
    isolation_paint(state, &new_state);
    return new_state;
}

// Aplica a em loop até não haver mais mudanças
void apply_rules_loop(Gamestate **state) {
    int changed;
    do {
        Gamestate *new_state = apply_rules(*state);
        changed = 0;
        for (int i = 0; i < (*state)->lines; i++) {
            if (memcmp((*state)->board[i], new_state->board[i], (*state)->columns * sizeof(char)) != 0) {
                changed = 1;
                break;
            }
        }
        if (changed) {
            new_state->prev = *state;
            new_state->next = NULL;
            (*state)->next = new_state;
            (*state) = (*state)->next;
        } else {
            free_gamestate(new_state);
        }
    } while (changed);
}

// Função recursiva para encontrar uma solução
int find_solution(Gamestate *state, int row, int col) {
    if (row >= state->lines || col >= state->columns) {
        if (check_solved(state))
            return 1; // Solution found
        return 0;
    }
    // Move to the next cell
    int next_row = (col == state->columns - 1) ? row + 1 : row;
    int next_col = (col == state->columns - 1) ? 0 : col + 1;
    char cell = state->board[row][col];
    if (islower(cell)) {
        // Option 1: Paint the cell (uppercase)
        if (is_valid_paint(state, row, col, toupper(cell))) {
            state->board[row][col] = toupper(cell);
            if (find_solution(state, next_row, next_col))
                return 1; // Solution found
            state->board[row][col] = cell; // Revert
        }
        // Option 2: Cross out the cell
        if (is_valid_mark(state, row, col)) {
            state->board[row][col] = '#';
            if (find_solution(state, next_row, next_col))
                return 1; // Solution found
        }
        state->board[row][col] = cell; // Revert
    } else {
        // Skip non-lowercase cells
        if (find_solution(state, next_row, next_col))
            return 1; // Solution found
    }
    return 0; // No solution found
}

// Comando para resolver o jogo
void solve(Gamestate **state) {
    Gamestate *solution = duplicate_gamestate(*state);
    if (find_solution(solution, 0, 0) && check_solved(solution)){
        (*state)->next = solution;
        solution->prev = *state;
        (*state) = (*state)->next;
    }
    else {
        free_gamestate(solution);
        printf("Não existe solução possivel.\n");
    }
}

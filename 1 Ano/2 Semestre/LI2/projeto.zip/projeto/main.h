#ifndef MAIN_H
#define MAIN_H

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>

typedef struct Gamestate {
    int lines, columns;
    char **board;
    struct Gamestate *next;
    struct Gamestate *prev;
} Gamestate;

// guiao1.c
void print_board(Gamestate *state);
void save_game(const char *filename, Gamestate *state);
void reload_game(Gamestate **current_state, char *filename);
void load_game(const char *filename, Gamestate *state);
void mark_paint(Gamestate **current_state, int row, int col, int mark);

// guiao2.c
void undo(Gamestate **state);
int verify_paint(Gamestate *state, int row, int col, int supress);
int verify_mark(Gamestate *state, int row, int col, int supress);
int verify(Gamestate *state, int supress);

// guiao3.c
void flood_fill(Gamestate *state, int row, int col, int **visited);
int check_connected(Gamestate *state, int **visited);
int are_painted_cells_connected(Gamestate *state);

// guiao4.c
void mark_next_painted(Gamestate *state, Gamestate **new_state);
void paint_next_mark(Gamestate *state, Gamestate **new_state);
void isolation_paint(Gamestate *state, Gamestate **new_state);
Gamestate *apply_rules(Gamestate *state);
void apply_rules_loop(Gamestate **state);
int find_solution(Gamestate *state, int row, int col);
void solve(Gamestate **state);

// auxiliar.c
int exit_error(char *message);
int check_loaded(Gamestate *state);
int input_check(char col, int row, Gamestate *state);
void init_gamestate(Gamestate *state);
void free_gamestate(Gamestate *state);
Gamestate *duplicate_gamestate(Gamestate *state);
int check_solved(Gamestate *state);
int is_valid_paint(Gamestate *state, int row, int col, char check);
int is_valid_mark(Gamestate *state, int row, int col);

#endif

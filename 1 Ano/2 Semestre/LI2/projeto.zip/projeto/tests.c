#include <CUnit/Basic.h>
#include <stdlib.h> 
#include "main.h"

#define TESTSIZE 5

//auxiliares

// Testa input_check
void testar_input_check(void) {
    Gamestate s = {.lines = 5, .columns = 5};

    CU_ASSERT_EQUAL(input_check('a', 1, &s), 1);
    CU_ASSERT_EQUAL(input_check('e', 5, &s), 1);
    CU_ASSERT_EQUAL(input_check('c', 3, &s), 1);
}

void testar_input_check_invalido(void) {
      Gamestate s = {.lines = 5, .columns = 5};

    CU_ASSERT_EQUAL(input_check('f', 1, &s), 0);  // coluna fora
    CU_ASSERT_EQUAL(input_check('a', 0, &s), 0);  // linha abaixo do mínimo
    CU_ASSERT_EQUAL(input_check('a', 6, &s), 0);  // linha acima do máximo
    CU_ASSERT_EQUAL(input_check('z', 2, &s), 0);  // coluna completamente inválida
}

void testar_check_loaded_true(void) {
    Gamestate state = {.lines = 3, .columns = 4};
    CU_ASSERT_EQUAL(check_loaded(&state), 1);
}

void testar_check_loaded_false(void) {
    Gamestate s1 = {.lines = 0, .columns = 4};
    Gamestate s2 = {.lines = 3, .columns = 0};
    Gamestate s3 = {.lines = 0, .columns = 0};
    CU_ASSERT_EQUAL(check_loaded(&s1), 0);
    CU_ASSERT_EQUAL(check_loaded(&s2), 0);
    CU_ASSERT_EQUAL(check_loaded(&s3), 0);
}

// Testar se a memória está a ser libertada corretamente
void inicializar_estado(Gamestate *state, char tabuleiro[TESTSIZE][TESTSIZE]);
void testar_free_gamestate(void) {
    Gamestate *s1 = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'a','b','c','d','e'},
        {'f','g','h','i','j'},
        {'k','l','m','n','o'},
        {'p','q','r','s','t'},
        {'u','v','w','x','y'}
    };
    inicializar_estado(s1, tabuleiro);

    mark_paint(&s1, 1, 1, 0);
    mark_paint(&s1, 2, 2, 1);

    free_gamestate(s1); 
}

void testar_check_loaded(void) {
    Gamestate state1 = {.lines = 0, .columns = 0};
    CU_ASSERT_EQUAL(check_loaded(&state1), 0);

    Gamestate state2 = {.lines = 5, .columns = 5};
    CU_ASSERT_EQUAL(check_loaded(&state2), 1);
}

void testar_check_solved(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A','B','C','D','E'},
        {'F','G','H','I','J'},
        {'K','L','M','N','O'},
        {'P','Q','R','S','T'},
        {'U','V','W','X','y'} 
    };
    inicializar_estado(state, tabuleiro);
    CU_ASSERT_EQUAL(check_solved(state), 0);
    state->board[4][4] = 'Y'; 
    CU_ASSERT_EQUAL(check_solved(state), 1);
    free_gamestate(state);
}

void testar_is_valid_paint_true(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'a','b','c','x','x'},
        {'d','e','f','x','x'},
        {'g','h','i','x','x'},
        {'x','x','x','x','x'},
        {'x','x','x','x','x'}
    };
    
    inicializar_estado(state, tabuleiro);
    CU_ASSERT_EQUAL(is_valid_paint(state, 1, 1, 'x'), 1); 
    free_gamestate(state);
}

void testar_is_valid_paint_false(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'a','b','c','x','x'},
        {'d','e','f','x','x'},
        {'g','e','i','x','x'},
        {'x','x','x','x','x'},
        {'x','x','x','x','x'}
    };
    inicializar_estado(state, tabuleiro);
    CU_ASSERT_EQUAL(is_valid_paint(state, 1, 1, 'e'), 0); 
    CU_ASSERT_EQUAL(is_valid_paint(state, 2, 1, 'e'), 0);
    free_gamestate(state);
}

void testar_is_valid_mark_true(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A','B','C','x','x'},
        {'D','e','F','x','x'},
        {'G','H','I','x','x'},
        {'x','x','x','x','x'},
        {'x','x','x','x','x'}
    };
    inicializar_estado(state, tabuleiro);
    CU_ASSERT_EQUAL(is_valid_mark(state, 1, 1), 1); 
    free_gamestate(state);
}

void testar_is_valid_mark_false(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'#','B','C','A','x'},
        {'D','e','F','x','x'},
        {'G','H','I','x','x'},
        {'x','x','x','x','x'},
        {'x','x','x','x','x'}
    };
    inicializar_estado(state, tabuleiro);
    
    CU_ASSERT_EQUAL(is_valid_mark(state, 1, 1), 0); 
    
    state->board[0][1] = 'B'; 
    state->board[2][1] = '#'; 
    CU_ASSERT_EQUAL(is_valid_mark(state, 1, 1), 0); 

    free_gamestate(state);
}

// guiao1

// Inicializa Gamestate com um tabuleiro fixo
void inicializar_estado(Gamestate *state, char tabuleiro[TESTSIZE][TESTSIZE]) {
    state->lines = TESTSIZE;
    state->columns = TESTSIZE;
    state->prev = NULL;
    state->next = NULL;

    state->board = malloc(TESTSIZE * sizeof(char *));
    for (int i = 0; i < TESTSIZE; i++) {
        state->board[i] = malloc(TESTSIZE * sizeof(char));
        for (int j = 0; j < TESTSIZE; j++) {
            state->board[i][j] = tabuleiro[i][j];
        }
    }
}

// Testa print_board (visual)
void testar_print_board(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'1', '2', '3', '4', '5'},
        {'6', '7', '8', '9', '0'},
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'}
    };
    inicializar_estado(state, tabuleiro);
    print_board(state); 
    free_gamestate(state);
}

// Testa guardar e carregar estado
void testar_save_load(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);
    save_game("test_board.txt", state);

    Gamestate *loaded = malloc(sizeof(Gamestate));  
    loaded->prev = NULL;                            
    loaded->next = NULL;
    load_game("test_board.txt", loaded);

    CU_ASSERT_EQUAL(loaded->lines, state->lines);
    CU_ASSERT_EQUAL(loaded->columns, state->columns);

    for (int i = 0; i < TESTSIZE; i++) {
        for (int j = 0; j < TESTSIZE; j++) {
            CU_ASSERT_EQUAL(state->board[i][j], loaded->board[i][j]);
        }
    }

    free_gamestate(state);
    free_gamestate(loaded);
}


void testar_load_game_fopen_fail(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    state->prev = NULL;
    state->next = NULL;

    load_game("/caminho/que/nao/existe.txt", state);

    CU_PASS("load_game com caminho inválido não causou crash");

    free(state);
}

void testar_reload_game(void) {
    char tabuleiro1[TESTSIZE][TESTSIZE] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };

    char tabuleiro2[TESTSIZE][TESTSIZE] = {
        {'z', 'y', 'x', 'w', 'v'},
        {'u', 't', 's', 'r', 'q'},
        {'p', 'o', 'n', 'm', 'l'},
        {'k', 'j', 'i', 'h', 'g'},
        {'f', 'e', 'd', 'c', 'b'}
    };

    Gamestate *state_temp = malloc(sizeof(Gamestate));
    CU_ASSERT_PTR_NOT_NULL_FATAL(state_temp);

    inicializar_estado(state_temp, tabuleiro1);
    save_game("jogo1.txt", state_temp);
    free_gamestate(state_temp);

    state_temp = malloc(sizeof(Gamestate));
    CU_ASSERT_PTR_NOT_NULL_FATAL(state_temp);
    inicializar_estado(state_temp, tabuleiro2);
    save_game("jogo2.txt", state_temp);

    free_gamestate(state_temp);

    Gamestate *estado_atual = malloc(sizeof(Gamestate));
    CU_ASSERT_PTR_NOT_NULL_FATAL(estado_atual);
    load_game("jogo1.txt", estado_atual);

    reload_game(&estado_atual, "jogo2.txt");

    for (int i = 0; i < TESTSIZE; i++) {
        for (int j = 0; j < TESTSIZE; j++) {
            CU_ASSERT_EQUAL(estado_atual->board[i][j], tabuleiro2[i][j]);
        }
    }
    free_gamestate(estado_atual);
}

// Testa mark_paint pintar (minúscula → maiúscula)
void testar_mark_paint_pintar(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);

    Gamestate *original = state;
    mark_paint(&state, 2, 2, 0);

    CU_ASSERT_EQUAL(state->board[2][2], 'M');
    CU_ASSERT_EQUAL(original->board[2][2], 'm');
    CU_ASSERT_PTR_EQUAL(state->prev, original);
    CU_ASSERT_PTR_NULL(state->next);

    free_gamestate(state); 
}

// Testa mark_paint riscar (#)
void testar_mark_paint_riscar(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);

    mark_paint(&state, 4, 4, 1);

    CU_ASSERT_EQUAL(state->board[4][4], '#');
    CU_ASSERT_EQUAL(state->prev->board[4][4], 'y');

    free_gamestate(state);
}

//guiao 2

// Testa undo
void testar_undo(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'a','b','c','d','e'},
        {'f','g','h','i','j'},
        {'k','l','m','n','o'},
        {'p','q','r','s','t'},
        {'u','v','w','x','y'}
    };
    inicializar_estado(state, tabuleiro);
    state->lines = TESTSIZE;
    state->columns = TESTSIZE;

    mark_paint(&state, 0, 0, 0); 
    CU_ASSERT_EQUAL(state->board[0][0], 'A');

    mark_paint(&state, 1, 1, 1); 
    CU_ASSERT_EQUAL(state->board[1][1], '#');

    Gamestate *descartado = state;

    undo(&state);

    // Verificações após undo
    CU_ASSERT_EQUAL(state->board[0][0], 'A');  
    CU_ASSERT_EQUAL(state->board[1][1], 'g');  

    free_gamestate(state);         
    free_gamestate(descartado);   
}

// Testa undo quando não existe estado anterior
void testar_undo_sem_prev(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'a','b','c','d','e'},
        {'f','g','h','i','j'},
        {'k','l','m','n','o'},
        {'p','q','r','s','t'},
        {'u','v','w','x','y'}
    };
    inicializar_estado(state, tabuleiro);

    undo(&state);

    CU_ASSERT_PTR_NOT_NULL(state);
    CU_ASSERT_EQUAL(state->board[0][0], 'a');

    free_gamestate(state);
}

void testar_verify_paint(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'A', 'b', 'C', 'd', 'E'},
        {'F', 'G', 'H', 'I', 'J'},
        {'K', 'L', 'M', 'N', 'O'},
        {'P', 'Q', 'R', 'S', 'T'},
        {'A', 'U', 'V', 'W', 'X'}  
    };
    inicializar_estado(state, tabuleiro);

    int erros = verify(state, 1);

    CU_ASSERT_EQUAL(erros, 1); 

    free_gamestate(state);
}

void testar_verify_paint2(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'A', 'b', 'C', 'd', 'E'},
        {'F', 'G', 'H', 'I', 'J'},
        {'K', 'L', 'M', 'L', 'O'},
        {'P', 'Q', 'R', 'S', 'T'},
        {'b', 'U', 'V', 'W', 'X'}  
    };
    inicializar_estado(state, tabuleiro);

    int erros = verify(state, 1);

    CU_ASSERT_EQUAL(erros, 1); 

    free_gamestate(state);
}

void testar_verify_paint_riscadas(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'A', 'B', 'C', 'D', 'E'},
        {'F', '#', '#', 'I', 'J'},
        {'K', 'L', 'M', 'N', 'O'},
        {'P', 'Q', 'R', 'S', 'T'},
        {'b', 'U', 'V', 'W', 'X'}  
    };
    inicializar_estado(state, tabuleiro);

    int erros = verify(state, 1);

    CU_ASSERT_EQUAL(erros, 2);

    free_gamestate(state);
}

void testar_verify_mark(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'A', 'B', 'C', 'D', 'E'},
        {'F', '#', 'H', 'I', 'J'},
        {'K', 'l', 'M', 'N', 'O'}, 
        {'P', 'Q', 'R', 'S', 'T'},
        {'U', 'V', 'W', 'X', 'Y'}
    };
    inicializar_estado(state, tabuleiro);
    int erros = verify(state, 1);
    CU_ASSERT(erros >= 1);
    free_gamestate(state);
}

void testar_verify_mark_paint(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'A', 'B', 'C', 'D', 'E'},
        {'F', '#', 'G', 'I', 'J'}, 
        {'K', 'L', 'M', 'N', 'O'},
        {'P', 'Q', 'R', 'S', 'T'},
        {'U', 'V', 'W', 'X', 'Y'}
    };
    inicializar_estado(state, tabuleiro);
    int erros = verify(state, 1);
    CU_ASSERT_EQUAL(erros, 0);
    free_gamestate(state);
}

void testar_verify_mark_direita(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A','B','C','D','E'},
        {'F','#','b','I','J'},
        {'K','L','M','N','O'},
        {'P','Q','R','S','T'},
        {'U','V','W','X','Y'}
    };
    inicializar_estado(state, tabuleiro);
    CU_ASSERT_EQUAL(verify(state, 1), 1);
    free_gamestate(state);
}

void testar_verify_mark_esquerda(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A','B','C','D','E'},
        {'b','#','H','I','J'}, 
        {'K','L','M','N','O'},
        {'P','Q','R','S','T'},
        {'U','V','W','X','Y'}
    };
    inicializar_estado(state, tabuleiro);
    CU_ASSERT_EQUAL(verify(state, 1), 1);
    free_gamestate(state);
}

void testar_verify_mark_cima(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A','b','C','D','E'},
        {'F','#','H','I','J'}, 
        {'K','L','M','N','O'},
        {'P','Q','R','S','T'},
        {'U','V','W','X','Y'}
    };
    inicializar_estado(state, tabuleiro);
    CU_ASSERT_EQUAL(verify(state, 1), 1);
    free_gamestate(state);
}

void testar_verify_mark_baixo(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A','B','C','D','E'},
        {'F','#','H','I','J'},
        {'K','b','M','N','O'}, 
        {'P','Q','R','S','T'},
        {'U','V','W','X','Y'}
    };
    inicializar_estado(state, tabuleiro);
    CU_ASSERT_EQUAL(verify(state, 1), 1);
    free_gamestate(state);
}

void testar_verify_pintadas_duplicadas(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A', 'b', 'C', 'd', 'e'},
        {'F', 'g', 'H', 'i', 'j'},
        {'K', 'L', 'M', 'N', 'O'},
        {'P', 'Q', 'R', 'S', 'T'},
        {'A', 'U', 'V', 'W', 'X'} 
    };
    inicializar_estado(state, tabuleiro);

    CU_ASSERT_EQUAL(verify(state, 1), 1); 

    free_gamestate(state);
}

void testar_verify_riscadas_invalidas(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A', 'B', 'C', 'D', 'E'},
        {'F', '#', 'H', 'I', 'J'},
        {'K', 'l', 'M', 'N', 'O'}, 
        {'P', 'Q', 'R', 'S', 'T'},
        {'U', 'V', 'W', 'X', 'Y'}
    };
    inicializar_estado(state, tabuleiro);

    CU_ASSERT(verify(state, 1) >= 1);

    free_gamestate(state);
}

void testar_verify_pintadas_desligadas(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A', 'b', 'c', 'd', 'E'}, 
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);

    CU_ASSERT_EQUAL(verify(state, 1), 1); 
    free_gamestate(state);
}

void testar_verify_sem_erros(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A', 'B', 'C', 'D', 'E'},
        {'F', 'G', 'H', 'I', 'J'},
        {'K', 'L', 'M', 'N', 'O'},
        {'P', 'Q', 'R', 'S', 'T'},
        {'U', 'V', 'W', 'X', 'Y'}
    };
    inicializar_estado(state, tabuleiro);

    CU_ASSERT_EQUAL(verify(state, 1), 0); 

    free_gamestate(state);
}

//guiao3

//Testa se existe caminho sem nenhuma casa pintada
void testar_sem_pintados(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);

    CU_ASSERT_EQUAL(are_painted_cells_connected(state), 1);

    free_gamestate(state);
}

// Testa se existe caminho com apenas uma casa pintada
void testar_um_pintado(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'A', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);

    CU_ASSERT_EQUAL(are_painted_cells_connected(state), 1);

    free_gamestate(state);
}

// Testa se as casas pintadas estão ligadas
void testar_varios_pintados_ligados(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'A', 'B', 'C', 'd', 'e'},
        {'f', 'g', 'C', 'i', 'j'},
        {'k', 'l', 'M', 'N', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);

    CU_ASSERT_EQUAL(are_painted_cells_connected(state), 1);

    free_gamestate(state);
}

// Testa se casas pintadas não estão todas ligadas
void testar_varios_pintados_naoligados(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[TESTSIZE][TESTSIZE] = {
        {'A', 'b', 'c', 'd', 'E'},
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);

    CU_ASSERT_EQUAL(are_painted_cells_connected(state), 0);

    free_gamestate(state);
}


//guiao4

//Testa se risca todas as casas iguais a uma branca
void testar_regra1_mark_next_painted(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'G', 'g', 'h', 'i'},
        {'j', 'k', 'g', 'm', 'n'},
        {'o', 'p', 'q', 'r', 's'},
        {'t', 'u', 'v', 'w', 'x'}
    };
    inicializar_estado(state, tabuleiro);
    Gamestate *new_state = duplicate_gamestate(state);

    mark_next_painted(state, &new_state);

    CU_ASSERT_EQUAL(new_state->board[1][2], '#');
    CU_ASSERT_EQUAL(state->board[2][2], 'g');

    free_gamestate(new_state);
    free_gamestate(state);
}

//Testa se pinta as casas vizinhas de uma casa riscada
void testar_regra2_paint_next_mark(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', '#', 'g', 'h', 'i'},
        {'j', 'k', 'l', 'm', 'n'},
        {'o', 'p', 'q', 'r', 's'},
        {'t', 'u', 'v', 'w', 'x'}
    };
    inicializar_estado(state, tabuleiro);
    Gamestate *new_state = duplicate_gamestate(state);

    paint_next_mark(state, &new_state);

    CU_ASSERT_EQUAL(new_state->board[0][1], 'B');
    CU_ASSERT_EQUAL(new_state->board[1][0], 'F');
    CU_ASSERT_EQUAL(new_state->board[1][2], 'G');
    CU_ASSERT_EQUAL(new_state->board[2][1], 'K');

    free_gamestate(new_state);
    free_gamestate(state);
}

//Testa se pinta as casas isoladas
void testar_regra3_isolation_paint(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'#', '#', '#', 'd', 'e'},
        {'a', 'g', 'a', 'b', 'c'},
        {'f', 'c', 'd', 'g', 'k'},
        {'c', 'd', 'e', 'f', '#'},
        {'h', 'i', 'j', 'k', 'L'}
    };
    inicializar_estado(state, tabuleiro);
    Gamestate *new_state = duplicate_gamestate(state);

    isolation_paint(state, &new_state);

    CU_ASSERT_EQUAL(new_state->board[4][3], 'K');

    free_gamestate(new_state);
    free_gamestate(state);
}

void testar_apply_rules_simples(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'a', 'b', 'c', 'd', 'e'},
        {'f', 'G', 'h', 'g', 'j'},
        {'k', 'l', 'm', 'n', 'o'},
        {'p', 'q', 'r', 's', 't'},
        {'u', 'v', 'w', 'x', 'y'}
    };
    inicializar_estado(state, tabuleiro);
    Gamestate *resultado = apply_rules(state);

    CU_ASSERT_EQUAL(resultado->board[1][3], '#');

    free_gamestate(resultado);
    free_gamestate(state);
}

void testar_apply_rules_loop_estabiliza(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'a', 'b', 'a', 'b', 'a'},
        {'#', 'c', 'd', 'e', '#'},
        {'a', 'b', 'a', 'b', 'a'},
        {'f', 'g', 'h', 'i', 'j'},
        {'k', 'l', 'm', 'n', 'o'}
    };
    inicializar_estado(state, tabuleiro);

    apply_rules_loop(&state);

    CU_ASSERT_EQUAL(state->board[0][0], 'A'); 
    CU_ASSERT_EQUAL(state->board[0][4], 'A'); 
    CU_ASSERT_EQUAL(state->board[1][1], 'C');
    CU_ASSERT_EQUAL(state->board[2][0], 'A'); 
    CU_ASSERT_EQUAL(state->board[2][4], 'A'); 
    
    free_gamestate(state);
}

void testar_apply_rules_sem_efeito(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'A','B','C','D','E'},
        {'F','G','H','I','J'},
        {'K','L','M','N','O'},
        {'P','Q','R','S','T'},
        {'U','V','W','X','Y'}
    };
    inicializar_estado(state, tabuleiro);
    Gamestate *res = apply_rules(state);
    CU_ASSERT_EQUAL(memcmp(state->board[0], res->board[0], 5), 0);
    free_gamestate(state);
    free_gamestate(res);
}

void testar_apply_rules_bloqueio_isolamento(void) {
    Gamestate *state = malloc(sizeof(Gamestate));
    char tabuleiro[5][5] = {
        {'#', '#', '#', '#', '#'},
        {'#', 'g', 'a', 'b', '#'},
        {'#', '#', '#', '#', '#'},
        {'c', 'd', 'e', 'f', 'g'},
        {'h', 'i', 'j', 'k', 'l'}
    };
    inicializar_estado(state, tabuleiro);

    Gamestate *resultado = apply_rules(state);

    CU_ASSERT_EQUAL(resultado->board[1][2], 'A');

    free_gamestate(resultado);
    free_gamestate(state);
}


// Função principal
int main() {
    if (CUE_SUCCESS != CU_initialize_registry())
        return CU_get_error();

    CU_basic_set_mode(CU_BRM_VERBOSE);

    CU_pSuite suite = CU_add_suite("suite_tabuleiro", 0, 0);
    if (suite == NULL) {
        CU_cleanup_registry();
        return CU_get_error();
    }

    CU_add_test(suite, "input_check", testar_input_check);
    CU_add_test(suite, "input_check invalido", testar_input_check_invalido);
    CU_add_test(suite, "check loaded", testar_check_loaded_true);
    CU_add_test(suite, "check loaded", testar_check_loaded_false);
    CU_add_test(suite, "is_valid", testar_is_valid_paint_false);
    //CU_add_test(suite, "is_valid", testar_is_valid_paint_true);
    CU_add_test(suite, "is_valid_mark true", testar_is_valid_mark_true);
    //CU_add_test(suite, "is_valid_mark false", testar_is_valid_mark_false);
    CU_add_test(suite, "free_gamestate", testar_free_gamestate);
    CU_add_test(suite,"check_loaded", testar_check_loaded);
    CU_add_test(suite,"check_solved", testar_check_solved);
    CU_add_test(suite, "save/load", testar_save_load);
    CU_add_test(suite, "load_game fopen fail", testar_load_game_fopen_fail);
    CU_add_test(suite, "reload", testar_reload_game);
    CU_add_test(suite, "mark_paint pintar", testar_mark_paint_pintar);
    CU_add_test(suite, "mark_paint riscar", testar_mark_paint_riscar);
    CU_add_test(suite, "print_board", testar_print_board);
    CU_add_test(suite, "verify_paint", testar_verify_paint);
    CU_add_test(suite,"verify_paint2", testar_verify_paint2);
    CU_add_test(suite, "verify_paint_riscadas", testar_verify_paint_riscadas);
    CU_add_test(suite, "verify_mark", testar_verify_mark);
    CU_add_test(suite, "verify_mark", testar_verify_mark_baixo);
    CU_add_test(suite, "verify_mark", testar_verify_mark_cima);
    CU_add_test(suite, "verify_mark", testar_verify_mark_direita);
    CU_add_test(suite, "verify_mark", testar_verify_mark_esquerda);
    CU_add_test(suite, "verify_mark_paint", testar_verify_mark_paint);
    CU_add_test(suite, "verify - pintadas duplicadas", testar_verify_pintadas_duplicadas);
    CU_add_test(suite, "verify - risco inválido", testar_verify_riscadas_invalidas);
    CU_add_test(suite, "verify - pintadas desligadas", testar_verify_pintadas_desligadas);
    CU_add_test(suite, "verify - sem erros", testar_verify_sem_erros);
    CU_add_test(suite, "undo", testar_undo);
    CU_add_test(suite, "sem casas pintadas", testar_sem_pintados);
    CU_add_test(suite, "uma casa pintada", testar_um_pintado);
    CU_add_test(suite, "pintados ligados", testar_varios_pintados_ligados);
    CU_add_test(suite, "pintados não ligados", testar_varios_pintados_naoligados);
    CU_add_test(suite, "Regra 1", testar_regra1_mark_next_painted);
    CU_add_test(suite, "Regra 2", testar_regra2_paint_next_mark);
    CU_add_test(suite, "Regra 3", testar_regra3_isolation_paint);
    CU_add_test(suite, "Apply rules (simples)", testar_apply_rules_simples);
    CU_add_test(suite, "Apply rules (loop estabiliza)", testar_apply_rules_loop_estabiliza);
    CU_add_test(suite, "Apply rules (isolamento)", testar_apply_rules_bloqueio_isolamento);
    CU_add_test(suite, "Apply rules (sem efeito)", testar_apply_rules_sem_efeito);


    CU_basic_run_tests();
    return CU_get_error();
}

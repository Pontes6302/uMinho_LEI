#include "main.h"

// Função para imprimir o tabuleiro.
void print_board(Gamestate *state) {
    for (int i = 0; i < state->lines; i++) {
        for (int j = 0; j < state->columns; j++) {
            printf("%c ", state->board[i][j]);
        }
        printf("\n");
    }
}

//Função para guardar o estado do jogo.
void save_game(const char *filename, Gamestate *state) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Failed to save game");
        return;
    }
    Gamestate *current = state;
    fprintf(file, "%d %d\n", current->lines, current->columns);
    int is_first = 1;
    while (current != NULL) {
        if (is_first == 0)
            fprintf(file, "\n-\n");
        is_first = 0;
        for (int i = 0; i < current->lines; i++) {
            for (int j = 0; j < current->columns; j++) {
                fputc(current->board[i][j], file);
            }
            if (i < current->lines - 1)
                fputc('\n', file);
        }
        current = current->prev;
    }
    fclose(file);
}

//Função para recarregar o estado do jogo.
void reload_game(Gamestate **current_state, char *filename) {
    free_gamestate(*current_state);
    *current_state = malloc(sizeof(Gamestate));
    if (*current_state == NULL)
        exit_error("Failed to allocate memory");
    init_gamestate(*current_state);
    load_game(filename, *current_state);
}

//Função para carregar o estado do jogo.
void load_game(const char *filename, Gamestate *current) {
    FILE *file = fopen(filename, "r");
    if (file == NULL)
        return;
    Gamestate *next_state = NULL;
    if (fscanf(file, "%d %d\n", &current->lines, &current->columns) != 2) {
        fclose(file);
        return;
    }
    while (1) {
        current->board = malloc(current->lines * sizeof(char *));
        for (int i = 0; i < current->lines; i++) {
            current->board[i] = malloc(current->columns * sizeof(char));
            for (int j = 0; j < current->columns; j++)
                current->board[i][j] = fgetc(file);
            fgetc(file);
        }
        // Check for the separator or end of file
        char separator[3];
        if (fgets(separator, sizeof(separator), file) == NULL || strcmp(separator, "-\n") != 0)
            break;
        // Prepare for the next state
        next_state = malloc(sizeof(Gamestate));
        init_gamestate(next_state);
        next_state->lines = current->lines;
        next_state->columns = current->columns;
        current->prev = next_state;
        next_state->next = current;
        current = current->prev;
    }
    current->prev = NULL;
    fclose(file);
}

//Função para marcar uma célula no tabuleiro. Se mark for 1, a célula é riscada, se for 0, a célula é pintada.
void mark_paint(Gamestate **current_state, int row, int col, int mark) {
    Gamestate *new_state = malloc(sizeof(Gamestate));
    if (new_state == NULL)
        exit_error("Failed to allocate memory");
    new_state->lines = (*current_state)->lines;
    new_state->columns = (*current_state)->columns;
    new_state->board = malloc(new_state->lines * sizeof(char *));
    if (new_state->board == NULL)
        exit_error("Failed to allocate memory");
    for (int i = 0; i < new_state->lines; i++) {
        new_state->board[i] = malloc(new_state->columns * sizeof(char));
        if (new_state->board[i] == NULL)
            exit_error("Failed to allocate memory");
        memcpy(new_state->board[i], (*current_state)->board[i], new_state->columns * sizeof(char));
    }
    new_state->prev = (*current_state);
    new_state->next = NULL;
    if (mark == 1)
        new_state->board[row][col] = '#';
    else if (mark == 0 && new_state->board[row][col] != '#')
        new_state->board[row][col] = new_state->board[row][col] - 32;
    (*current_state)->next = new_state;
    (*current_state) = (*current_state)->next;
}

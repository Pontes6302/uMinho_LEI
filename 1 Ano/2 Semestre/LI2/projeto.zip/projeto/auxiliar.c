#include "main.h"

// Função de saída de erro
int exit_error(char *message) {
    perror(message);
    exit (EXIT_FAILURE);
}

// Função para verificar se o tabuleiro está carregado
int check_loaded(Gamestate *state) {
    if (state->lines == 0 || state->columns == 0)
        return 0;
    return 1;
}

// Função para verificar se a coordenada do usuário é válida
int input_check(char col, int row, Gamestate *state) {
    if (col < 'a' || col > ('a' + state->columns - 1)
    || row < 1 || row > state->lines){
        printf("Coordenada inválida\n");
        return 0;
    }
    return 1;
}

// Função para inicializar o gamestate
void init_gamestate(Gamestate *state) {
    state->lines = 0;
    state->columns = 0;
    state->board = NULL;
    state->prev = NULL;
    state->next = NULL;
}

// Função para liberar a memória do gamestate
void free_gamestate(Gamestate *state) {
    if (state == NULL) return;
    if (state->prev != NULL)
        free_gamestate(state->prev);
    if (state->board != NULL){
        for (int i = 0; i < state->lines; i++)
            free(state->board[i]);
        free(state->board);
    }
    free(state);
}

// Função para duplicar o gamestate
Gamestate *duplicate_gamestate(Gamestate *state) {
    Gamestate *new_state = malloc(sizeof(Gamestate));
    if (new_state == NULL)
        exit_error("Failed to allocate memory");
    new_state->lines = state->lines;
    new_state->columns = state->columns;
    new_state->board = malloc(new_state->lines * sizeof(char *));
    if (new_state->board == NULL)
        exit_error("Failed to allocate memory");
    for (int i = 0; i < new_state->lines; i++) {
        new_state->board[i] = malloc(new_state->columns * sizeof(char));
        if (new_state->board[i] == NULL)
            exit_error("Failed to allocate memory");
        memcpy(new_state->board[i], state->board[i], new_state->columns * sizeof(char));
    }
    new_state->prev = NULL;
    new_state->next = NULL;
    return new_state;
}

// Verifica se o tabuleiro está resolvido
int check_solved(Gamestate *state) {
    if (verify(state, 1) != 0) 
        return 0; // Check if the board is valid
    for (int i = 0; i < state->lines; i++) {
        for (int j = 0; j < state->columns; j++) {
            if (islower(state->board[i][j])) 
                return 0; // Found a lowercase letter
        }
    }
    return 1;
}

// Verifica se uma casa pode ser pintada de acordo com as regras
int is_valid_paint(Gamestate *state, int row, int col, char check) {
    for (int i = 0; i < state->lines; i++) {
        if (state->board[i][col] == check) 
            return 0;
    }
    for (int j = 0; j < state->columns; j++) {
        if (state->board[row][j] == check) 
            return 0;
    }
    return 1;
}

// Verifica se uma casa pode ser marcada de acordo com as regras
int is_valid_mark(Gamestate *state, int row, int col) {
    if (col + 1 < state->columns && state->board[row][col + 1] == '#')
        return 0;
    if (col - 1 >= 0 && state->board[row][col - 1] == '#')
        return 0;
    if (row - 1 >= 0 && state->board[row - 1][col] == '#')
        return 0;
    if (row + 1 < state->lines && state->board[row + 1][col] == '#')
        return 0;
    return 1;
}

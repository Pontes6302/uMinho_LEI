#include "main.h"

int main(void) {
    char *command = malloc(sizeof(char) * 20);
    if (command == NULL)
        exit_error("Failed to allocate memory");
    Gamestate *current_state = malloc(sizeof(Gamestate));
    if (current_state == NULL)
        exit_error("Failed to allocate memory");
    init_gamestate(current_state);
    while (1){ 
        if (fgets(command, 20, stdin) == NULL)
            exit_error("Error reading command");
        command[strcspn(command, "\n")] = 0; // Removes newline character
        if (strcmp(command, "s") == 0) {
            break;
        } else if (strncmp(command, "g", 1) == 0 && check_loaded(current_state)) {
            save_game(command+2, current_state);
        } else if (strncmp(command, "l", 1) == 0) {
            if (check_loaded(current_state))
                reload_game(&current_state, command+2);
            else
                load_game(command+2, current_state);
        } else if (strncmp(command, "b", 1) == 0 && check_loaded(current_state)) {
            int row = 0;
            char col = '\0';
            if (strlen(command) > 2) {
                col = command[2];
                row = atoi(&command[3]);
            }
            if (col < 'a' || col > 'z' || row <= 0 || input_check(col, row, current_state) == 0 
                || (current_state->board[row - 1][col - 'a'] >= 'A' 
                && current_state->board[row - 1][col - 'a'] <= 'Z')) {
                continue;
            }
            mark_paint(&current_state, row - 1, col - 'a', 0);
        } else if (strncmp(command, "r", 1) == 0 && check_loaded(current_state)) {
            int row = 0;
            char col = '\0';
            if (strlen(command) > 2) {
                col = command[2];
                row = atoi(&command[3]);
            }
            if (col < 'a' || col > 'z' || row <= 0 || input_check(col, row, current_state) == 0) {
                continue;
            }
            mark_paint(&current_state, row - 1, col - 'a', 1);
        } else if (strncmp(command, "v", 1) == 0 && check_loaded(current_state)) {
            verify(current_state, 0);
        } else if (strncmp(command, "a", 1) == 0 && check_loaded(current_state)) {
            current_state->next = apply_rules(current_state);
            current_state->next->prev = current_state;
            current_state = current_state->next;
        } else if (strncmp(command, "A", 1) == 0 && check_loaded(current_state)) {
            apply_rules_loop(&current_state);
        } else if (strncmp(command, "R", 1) == 0 && check_loaded(current_state)) {
            solve(&current_state);
        } else if (strncmp(command, "d", 1) == 0 && check_loaded(current_state)) {
            undo(&current_state);
        } else {
            printf("Comando inválido\n");
        }
        print_board(current_state);
    }
    free_gamestate(current_state);
    free(command);
    return 0;
}
